#ifndef ABOUTAZURE2DIALOG_H
#define ABOUTAZURE2DIALOG_H

#include <QDialog>

QT_BEGIN_NAMESPACE
QT_END_NAMESPACE

class AboutAZURE2Dialog : public QDialog {
  Q_OBJECT

 public:
  AboutAZURE2Dialog(QWidget *parent=0);
  
};

#endif
